function follower() {
    document.getElementById("follower").className = "active";
    document.getElementById("following").className = "";
}

function following() {
    document.getElementById("following").className = "active";
    document.getElementById("follower").className = "";
}